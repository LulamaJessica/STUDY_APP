﻿namespace Handle
{
    public class Class1
    {
     
    }
}