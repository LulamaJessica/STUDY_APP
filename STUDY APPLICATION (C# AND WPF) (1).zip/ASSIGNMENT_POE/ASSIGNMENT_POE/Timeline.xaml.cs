﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ASSIGNMENT_POE
{
    /// <summary>
    /// Interaction logic for Timeline.xaml
    /// </summary>
    public partial class Timeline : Window
    {
        public Timeline()
        {
            InitializeComponent();
        }

        private void Enter_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                Handle.weeks = Convert.ToInt32(Txt_Ba_weeks.Text);
                Handle.start = dtP_start.SelectedDate.Value;
                Handle.end = Handle.start.AddDays(7 * Handle.weeks);

                Selfstudy obj1 = new Selfstudy();
                obj1.Show();
                this.Hide();

            }
            catch (Exception warning)
            {
                MessageBox.Show(warning.Message);
            }  
        }    

    }
}
