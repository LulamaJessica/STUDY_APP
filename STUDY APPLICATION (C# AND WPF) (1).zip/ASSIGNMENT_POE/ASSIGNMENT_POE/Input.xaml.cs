﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Reflection;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ASSIGNMENT_POE
{
    /// <summary>
    /// Interaction logic for Input.xaml
    /// </summary>
    public partial class Input : Window
    {
        public Input()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)

        {
            int counter = 0;
            Array.Resize(ref Handle.module_code, Handle.module_code.Length + 1);
            Array.Resize(ref Handle.module_Name, Handle.module_Name.Length + 1);
            Array.Resize(ref Handle.module_Credit, Handle.module_Credit.Length + 1);
            Array.Resize(ref Handle.module_Hours, Handle.module_Hours.Length + 1);

            try
            {
                Handle.module_code[counter] = Txt_Ba_1.Text;
                Handle.module_Name[counter] = Txt_Ba_2.Text;
                Handle.module_Credit[counter] = Convert.ToInt32(Txt_Ba_3.Text);
                Handle.module_Hours[counter] = Convert.ToInt32(Txt_Ba_4.Text);
                counter++;
                MessageBox.Show("Your information has been captured");

                Txt_Ba_1.Clear();
                Txt_Ba_2.Clear();
                Txt_Ba_3.Clear();
                Txt_Ba_4.Clear();

            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }
        private void Next_btn_Click(object sender, RoutedEventArgs e)
        {
            Timeline obj = new Timeline();
            obj.Show();
            this.Hide();
        }

        private void Cancel_btn_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
    }
