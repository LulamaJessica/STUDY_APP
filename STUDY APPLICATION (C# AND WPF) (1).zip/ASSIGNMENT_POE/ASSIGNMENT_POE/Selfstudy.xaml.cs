﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ASSIGNMENT_POE
{
    /// <summary>
    /// Interaction logic for Selfstudy.xaml
    /// </summary>
    public partial class Selfstudy : Window
    {
        int count = 0;
        public Selfstudy()
        {
            InitializeComponent();
            foreach (var item in Handle.module_Name)
            {
                myListBox.Items.Add(item);
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Array.Resize(ref Handle.hoursModule, Handle.hoursModule.Length + 1);
            Handle.hoursModule[count] = Convert.ToInt32(tboxSpent.Text);

            MessageBox.Show(Handle.hoursModule[count].ToString());

            for (int i = 0; i < Handle.module_Credit.Length; i++)
            {
                Handle.selfStudy = ((Handle.module_Credit[i] * 10) / Handle.weeks) - Handle.module_Hours[i];
            }

            for (int i = 0; i < Handle.module_Name.Length; i++)
            {
                Array.Resize(ref Handle.RemainingHours, Handle.RemainingHours.Length + 1);
                Handle.RemainingHours[i] = Handle.module_Hours[i] - Handle.hoursModule[i];
                MessageBox.Show("Remaining Hours" + Handle.RemainingHours[i].ToString());

            }

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            display obj1 = new display();
            obj1.Show();
            this.Hide();
        }
    }
}
