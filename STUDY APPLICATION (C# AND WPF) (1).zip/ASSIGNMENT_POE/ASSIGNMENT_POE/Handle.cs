﻿using System;

namespace ASSIGNMENT_POE
{
    public class Handle
    {
        public static String[] module_code = new String[0];
        public static String[] module_Name = new String[0];
        public static int[] module_Credit = new int[0];
        public static int[] module_Hours = new int[0];
        public static DateTime start;
        public static DateTime end;
        public static int weeks;
        public static int selfStudy;
        public static int[] RemainingHours = new int[0];
        public static int[] hoursModule = new int[0];
    }
}