﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Utilities.Collections;

namespace ASSIGNMENT_POE
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        DBAccess daAccess = new DBAccess();

        private void btn_register_Click(object sender, RoutedEventArgs e)
        {
            string username = txt_Username.Text;
            string password = txt_Password.Text;

            if (username.Equals(""))
            {
                MessageBox.Show("Please enter your username.");

            }
            else if (password.Equals(""))
            {
                MessageBox.Show("Please enter your password");
            }
            else {

                string query = "INSERT INTO[dbo].[User]([Password],[Username])VALUES(@Username,@Password)";

                SqlCommand insertCommand = new SqlCommand(query);
                insertCommand.Parameters.AddWithValue("@Username",username);
                insertCommand.Parameters.AddWithValue("@Password",password);

                int row =  daAccess.executeQuery(insertCommand);

                if (row == 1)
                {
                    Log LogIn = new Log();
                    LogIn.Show();
                }
                else {

                    MessageBox.Show("Error try again");
                }
            }   

        }

        private void btn_LogIn_Click(object sender, RoutedEventArgs e)
        {
            Log login = new Log();
            login.Show();
            this.Hide();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            txt_Password.Clear();
            txt_Username.Clear();

        }

        private void BTN_EXIT_Click(object sender, RoutedEventArgs e)
        {
            System.Environment.Exit(0);
        }
    }
    }

