﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ASSIGNMENT_POE
{
    /// <summary>
    /// Interaction logic for display.xaml
    /// </summary>
    public partial class display : Window
    {
        public display()
        {
            InitializeComponent();
        }

        private void btn_Displaying_Click(object sender, RoutedEventArgs e)
        {
            for (int i = 0; i < Handle.module_code.Length; i++)
            {
                txt_1_display.Text += "\n The module code is\t" + Handle.module_code[i] + "\n"
                                   + "The module name is \t" + Handle.module_Name[i] + "\n"
                                   + "The module credit is\t" + Handle.module_Credit[i] + "\n"
                                   + "The module hours are \t" + Handle.module_Credit[i] + "\n"
                                   + "Number of weeks\t" + Handle.weeks + "\n"
                                   + "Start Date\t" + Handle.start.ToString("yyyy-MM-dd") + "\n"
                                   + "End Date \t" + Handle.end.ToString("yyyy-MM-dd") + "\n"
                                   + "SelfStudy\t" + Handle.selfStudy + "Hours \n"
                                   + "Remaing time for SelfStudy\t " + Handle.RemainingHours[i].ToString();

            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            System.Environment.Exit(0);
        }
    }
}
