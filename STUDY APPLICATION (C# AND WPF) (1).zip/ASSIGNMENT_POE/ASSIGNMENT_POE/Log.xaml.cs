﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;

namespace ASSIGNMENT_POE
{
    /// <summary>
    /// Interaction logic for Log.xaml
    /// </summary>
    public partial class Log : Window
    {
        public Log()
        {
            InitializeComponent();
        }
        
        private void btn_register_Click(object sender, RoutedEventArgs e)
        {
            string username = txt_Username_LOG_IN.Text;
            string User_password = txt_Password_LOG_IN.Text;

            SqlConnection connect = new SqlConnection("Data Source=JESSICA\\SQLEXPRESS;Initial Catalog=Connection;Integrated Security=True");
            SqlCommand sda = new SqlCommand("SELECT * FROM [dbo].[User] WEHRE [Username] =@username and [Password] = @User_password'", connect);

            sda.Parameters.AddWithValue("@username" , txt_Username_LOG_IN);
            sda.Parameters.AddWithValue("@User_password", txt_Password_LOG_IN);

            SqlDataAdapter da = new SqlDataAdapter(sda);

                DataTable dtable = new DataTable();
                
                if (dtable.Rows.Count>0) {
                    //page that needed to load next
                    Input obj = new Input();
                    obj.Show();
                    this.Hide();
                }else
                MessageBox.Show("Error please try again", "alert", MessageBoxButton.OK);
            }
            //catch {
               
            //    txt_Password_LOG_IN.Clear();
            //    txt_Username_LOG_IN.Clear();

            //    txt_Username_LOG_IN.Focus();
            //}
            //finally {
            //    connect.Close();
 

        private void BTN_EXIT_Click(object sender, RoutedEventArgs e)
        {

            System.Environment.Exit(0);
        }
    
    }
}
